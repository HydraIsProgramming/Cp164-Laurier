"""
-------------------------------------------------------
Lab 4 Task 5
-------------------------------------------------------
Author:  Ranjot Sandhu
ID:      169020301
Email:   sand0301@mylaurier.ca
__updated__ = "2023-06-06"
-------------------------------------------------------
"""
from List_array import List

list1 = List()

list1.append(0)

list1.append(1)

list1.append(2)

list1.append(-1)

list1.append(-2)

print(list1[0])

list1[0] = 100

print(list1[0])

