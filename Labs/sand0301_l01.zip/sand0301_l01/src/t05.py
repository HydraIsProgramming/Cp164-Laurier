"""
-------------------------------------------------------
Lab 01 Task 05
-------------------------------------------------------
Author:  Ranjot Sandhu
ID:      169020301
Email:   sand0301@mylaurier.ca
__updated__ = "2023-05-15"
-------------------------------------------------------
"""
from Food_utilities import read_foods
file_variable = open("foods.txt", "r")
read_foods(file_variable)