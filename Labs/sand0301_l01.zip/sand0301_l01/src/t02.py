"""
-------------------------------------------------------
Lab 01 Task 02
-------------------------------------------------------
Author:  Ranjot Sandhu
ID:      169020301
Email:   sand0301@mylaurier.ca
__updated__ = "2023-05-15"
-------------------------------------------------------
"""

from Food import Food

s = Food("Butter Chicken", 2, True, 120)

print(s.__str__())
