"""
-------------------------------------------------------
Lab 01 Task 04
-------------------------------------------------------
Author:  Ranjot Sandhu
ID:      169020301
Email:   sand0301@mylaurier.ca
__updated__ = "2023-05-15"
-------------------------------------------------------
"""

from Food_utilities import read_food

source = read_food("Spanakopita|5|True|260")

print(source)
