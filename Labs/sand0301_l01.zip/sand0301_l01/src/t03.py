"""
-------------------------------------------------------
Lab 01 Task 03
-------------------------------------------------------
Author:  Ranjot Sandhu
ID:      169020301
Email:   sand0301@mylaurier.ca
__updated__ = "2023-05-15"
-------------------------------------------------------
"""

from Food_utilities import get_food

source = get_food()

print(source)
