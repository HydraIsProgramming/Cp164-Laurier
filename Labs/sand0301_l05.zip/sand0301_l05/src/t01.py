"""
-------------------------------------------------------
Lab 05 Task 01
-------------------------------------------------------
Author:  Ranjot Sandhu
ID:      169020301
Email:   sand0301@mylaurier.ca
__updated__ = "2023-06-12"
-------------------------------------------------------
"""

from functions import recurse

x = int(input("Enter a value: "))

y = int(input("Enter another value: "))

ans = recurse(x, y)

print(ans)