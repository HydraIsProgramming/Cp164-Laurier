"""
-------------------------------------------------------
Lab 05 Task 06
-------------------------------------------------------
Author:  Ranjot Sandhu
ID:      169020301
Email:   sand0301@mylaurier.ca
__updated__ = "2023-06-12"
-------------------------------------------------------
"""
from functions import bag_to_set

bag = [4, 5, 3, 4, 5, 2, 2, 4]

new_set = bag_to_set(bag)

print(new_set)
