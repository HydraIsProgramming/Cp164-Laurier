"""
-------------------------------------------------------
Lab 05 Task 02
-------------------------------------------------------
Author:  Ranjot Sandhu
ID:      169020301
Email:   sand0301@mylaurier.ca
__updated__ = "2023-06-12"
-------------------------------------------------------
"""
from functions import gcd

m = int(input("Enter a value: "))

n = int(input("Enter another value: "))

ans = gcd(m, n)

print(ans)



