"""
-------------------------------------------------------
Lab 05 Task 03
-------------------------------------------------------
Author:  Ranjot Sandhu
ID:      169020301
Email:   sand0301@mylaurier.ca
__updated__ = "2023-06-12"
-------------------------------------------------------
"""
from functions import vowel_count

s = input("Enter a string: ")

count = vowel_count(s)

print(count)
