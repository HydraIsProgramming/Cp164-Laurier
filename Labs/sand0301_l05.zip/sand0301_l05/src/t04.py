"""
-------------------------------------------------------
Lab 05 Task 04
-------------------------------------------------------
Author:  Ranjot Sandhu
ID:      169020301
Email:   sand0301@mylaurier.ca
__updated__ = "2023-06-12"
-------------------------------------------------------
"""
from functions import to_power

base = float(input("Enter the base value: "))

power = int(input("Enter the power: "))

ans = to_power(base, power)

print(ans)