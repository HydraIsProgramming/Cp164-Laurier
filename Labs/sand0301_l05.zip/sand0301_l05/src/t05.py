"""
-------------------------------------------------------
Lab 05 Task 05
-------------------------------------------------------
Author:  Ranjot Sandhu
ID:      169020301
Email:   sand0301@mylaurier.ca
__updated__ = "2023-06-12"
-------------------------------------------------------
"""
from functions import is_palindrome

s = input("Enter a string: ")

palindrome = is_palindrome(s)

print(palindrome)